ACS Content Fragment Import examples

Prepare before importing:
1. The template columns contain the model paths supplied by the requester.
2. Verify the deployed model field names, data types, required values and multi-reference settings.
3. Use a test dataset. All content, IDs and contact values are fictional examples.
4. Read the Read me worksheet included in each file. The first worksheet is the ACS input.

Model paths:
/conf/aemcloudproject/settings/dam/cfm/models/offer-detail
/conf/aemcloudproject/settings/dam/cfm/models/category
/conf/aemcloudproject/settings/dam/cfm/models/merchant-details
/conf/aemcloudproject/settings/dam/cfm/models/merchant-venue
/conf/aemcloudproject/settings/dam/cfm/models/offer-card
/conf/aemcloudproject/settings/dam/cfm/models/offer-cta

Offer Detail assets use:
/content/dam/aemcloudproject/cfs/offer-listing/offers

Import sequence:
01-venues.xlsx
02-categories.xlsx
03-cards.xlsx
04-ctas.xlsx
Check all four stages succeeded before continuing.
05-merchants.xlsx
Check merchant creation succeeded before continuing.
06-offers.xlsx

There are 16 candidate fragments across the files. Full CF reference paths and actual
line breaks demonstrate multi-valued references. Example IDs are preassigned; ACS does
not generate them. Existing fragments are located using path and name.

If a model has a business field named name or Name, ACS will populate it from the
technical name column. Resolve that mapping before using these examples on real models.
Blank cells must not be assumed to preserve existing values. No import was executed.

The separate ACS_CF_Examples_Reference.xlsx workbook contains all examples and a guide.
Do not upload that reference workbook to ACS; upload these six staged files instead.
