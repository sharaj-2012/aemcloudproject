(function (document, $) {
    "use strict";

    var REQUEST_FOR_ACTIVATION =
        "/var/workflow/models/request_for_activation";

    $(document).on("click", ".custom-page-activate", function () {
        waitForWorkflowDropdown();
    });

    function waitForWorkflowDropdown() {

        var observer = new MutationObserver(function () {

            var workflowSelect = getVisibleWorkflowSelect();

            if (workflowSelect) {
                observer.disconnect();
                selectRequestForActivation(workflowSelect);
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        setTimeout(function () {
            observer.disconnect();
        }, 5000);
    }

    function getVisibleWorkflowSelect() {
        return $(".js-cq-WorkflowStart-select:visible").last()[0];
    }

    function selectRequestForActivation(workflowSelect) {

        Coral.commons.ready(workflowSelect, function () {

            workflowSelect.value = REQUEST_FOR_ACTIVATION;

            $(workflowSelect).trigger("change");

			lockWorkflowSelect(workflowSelect);
        });
    }

	function lockWorkflowSelect(workflowSelect) {

    $(workflowSelect)
        .addClass("page-activate-workflow-locked")
        .attr("aria-disabled", "true")
        .attr("tabindex", "-1");
	}

})(document, Granite.$);